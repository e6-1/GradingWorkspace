package sorting;

public interface ISort {
	public void sort(int[] array);
}
